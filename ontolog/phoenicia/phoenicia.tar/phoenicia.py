import re
from typing import List

from ace_py import calculation

def _escape(s: str) -> str:
    return s.replace('"', '\\"')


def _cons_chain(items: List[str]) -> str:
    if not items:
        return 'Nil'
    out = items[-1]
    for item in reversed(items[:-1]):
        out = f'(Cons {item} {out})'
    return out

def _parse_block(path: str, body: str) -> List[dict]:
    """Parse the body of a single context block and return a list of function dicts."""
    lines = body.splitlines()
    funcs = []
    pending_doc: List[str] = []

    for raw in lines:
        line = raw.strip()
        if not line:
            continue
        if line.startswith('//'):
            pending_doc.append(line[2:].strip())
            continue

        if line.startswith('calc '):
            kind = 'calc'
            rest = line[5:].strip()
        elif line.startswith('cast '):
            kind = 'cast'
            rest = line[5:].strip()
        elif line.startswith('action '):
            kind = 'action'
            rest = line[7:].strip()
        else:
            pending_doc = []
            continue

        decl = rest
        if decl.endswith(';'):
            decl = decl[:-1].strip()

        if kind == 'action':
            m = re.match(r'([A-Za-z0-9_+\-*/]+)\s*:\s*(.*?)\s*$', decl)
            if not m:
                pending_doc = []
                continue
            name = m.group(1)
            lhs = m.group(2).strip()
            args = [a for a in re.split(r'\s+', lhs) if a] if lhs else []
            ret = None
        else:
            m = re.match(r'([A-Za-z0-9_+\-*/]+)\s*:\s*(.*?)\s*->\s*(\S+)$', decl)
            if not m:
                pending_doc = []
                continue
            name = m.group(1)
            lhs = m.group(2).strip()
            ret = m.group(3).strip()
            args = [a for a in re.split(r'\s+', lhs) if a] if lhs else []

        doc = ' '.join(pending_doc).strip()
        funcs.append({'path': path, 'name': name, 'args': args, 'ret': ret, 'kind': kind, 'doc': doc})
        pending_doc = []

    return funcs


@calculation
def parse(text: str) -> str:
    """Parse a Phoenicia file string and return an s-expression of rewrites.

    The function expects one or more `context "path" { ... }` blocks, each
    containing zero or more declarations immediately preceded by `calc`, `cast`,
    or `action`.  Declarations may be preceded by `//` line comments for
    documentation.  `calc` and `cast` declarations have the form
    `name : Type* -> Type;`; `action` declarations have the form
    `name : Type*;` and produce no output.
    """
    blocks = []
    for header in re.finditer(r'context\s*"([^"]+)"\s*\{', text):
        path = header.group(1)
        start = header.end()
        depth = 1
        i = start
        while i < len(text) and depth > 0:
            ch = text[i]
            if ch == '{':
                depth += 1
            elif ch == '}':
                depth -= 1
            elif ch == '/' and i + 1 < len(text) and text[i + 1] == '/':
                # skip to end of line
                while i < len(text) and text[i] != '\n':
                    i += 1
                continue
            i += 1
        body = text[start:i - 1]
        blocks.append((path, body))

    if not blocks:
        raise ValueError('Input does not contain any context "<path>" { ... } blocks')

    funcs = []
    for path, body in blocks:
        funcs.extend(_parse_block(path, body))

    parts: List[str] = ['(']

    # calc rewrites
    for fn in funcs:
        if fn['kind'] != 'calc':
            continue
        name = fn['name']
        args = fn['args']
        ret = fn['ret']

        pat_elems = [f'({a} ${i})' for i, a in enumerate(args)]
        pat = f'({name}' + ((' ' + ' '.join(pat_elems)) if pat_elems else '') + ')'

        cons_items = [f'"{_escape(name)}"'] + [f'${i}' for i in range(len(args))]
        cons_chain = _cons_chain(cons_items)
        podman = f'(podman_bc_lp32_v0 (!load "file://{_escape(fn["path"])}") {cons_chain})'
        rhs = f'({ret} {podman})'

        parts.extend(['    (', f'        {pat}', f'        {rhs}', '    )'])

    # cast rewrites
    for fn in funcs:
        if fn['kind'] != 'cast':
            continue
        name = fn['name']
        args = fn['args']
        ret = fn['ret']

        pat_elems = [f'({a} ${i})' for i, a in enumerate(args)]
        pat = f'({name}' + ((' ' + ' '.join(pat_elems)) if pat_elems else '') + ')'

        cons_items = [f'"{_escape(name)}"'] + [f'${i}' for i in range(len(args))]
        cons_chain = _cons_chain(cons_items)
        podman = f'(podman_bc_lp32_v0 (!load "file://{_escape(fn["path"])}") {cons_chain})'
        rhs = f'({ret} {podman})'

        parts.extend(['    (', f'        {pat}', f'        {rhs}', '    )'])

        if len(args) >= 1:
            src = args[0]
            auto_pat = f'({src} $0)'
            auto_rhs = f'({name} ({src} $0))'
            parts.extend(['    (', f'        {auto_pat}', f'        {auto_rhs}', '    )'])

    # action rewrites
    for fn in funcs:
        if fn['kind'] != 'action':
            continue
        name = fn['name']
        args = fn['args']

        pat_elems = [f'${i}' for i in range(len(args))]
        pat = f'({name}' + ((' ' + ' '.join(pat_elems)) if pat_elems else '') + ')'

        cons_items = [f'"{_escape(name)}"'] + [f'${i}' for i in range(len(args))] + ['Nil']
        cons_chain = _cons_chain(cons_items)
        rhs = f'(Action "podman_bc_lp32_v0" (concat_lp32 {cons_chain}))'

        parts.extend(['    (', f'        {pat}', f'        {rhs}', '    )'])

    # docs
    for fn in funcs:
        if fn['doc']:
            name = fn['name']
            doc = fn['doc']
            parts.extend(['    (', f'        (Doc (Module "{_escape(name)}"))', f'        (Str "{_escape(doc)}")', '    )'])

    parts.append(')')
    return '\n'.join(parts)


if __name__ == '__main__':
    import sys
    if len(sys.argv) == 2:
        text = open(sys.argv[1]).read()
    else:
        text = sys.stdin.read()
    print(parse(text))

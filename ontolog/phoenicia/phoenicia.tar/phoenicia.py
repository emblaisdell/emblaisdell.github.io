import re
from typing import List

from ace_py import calculation

def _escape(s: str) -> str:
    return s.replace('"', '\\"')


def _cons_chain(items: List[str]) -> str:
    if not items:
        return 'Nil'
    out = items[-1]
    for item in reversed(items[:-1]):
        out = f'(Cons {item} {out})'
    return out

def _parse_block(path: str, body: str) -> List[dict]:
    """Parse the body of a single calc block and return a list of function dicts."""
    lines = body.splitlines()
    funcs = []
    pending_doc: List[str] = []
    pending_annotations: List[str] = []

    for raw in lines:
        line = raw.strip()
        if not line:
            continue
        if line.startswith('//'):
            pending_doc.append(line[2:].strip())
            continue
        if line.startswith('@'):
            pending_annotations.append(line)
            continue

        decl = line
        if decl.endswith(';'):
            decl = decl[:-1].strip()

        m = re.match(r'([A-Za-z0-9_+\-*/]+)\s*:\s*(.*?)\s*->\s*(\S+)$', decl)
        if not m:
            pending_doc = []
            pending_annotations = []
            continue

        name = m.group(1)
        lhs = m.group(2).strip()
        ret = m.group(3).strip()

        args = [a for a in re.split(r'\s+', lhs) if a] if lhs else []
        is_cast = any(a.strip() == '@cast' or a.strip().startswith('@cast') for a in pending_annotations)
        doc = ' '.join(pending_doc).strip()

        funcs.append({'path': path, 'name': name, 'args': args, 'ret': ret, 'is_cast': is_cast, 'doc': doc})
        pending_doc = []
        pending_annotations = []

    return funcs


@calculation
def parse(text: str) -> str:
    """Parse a Phoenicia file string and return an s-expression of rewrites.

    The function expects one or more `calc "path" { ... }` blocks, each
    containing zero or more declarations of the form `name : Type* -> Type;`,
    optional `@` annotations on the line(s) immediately before a declaration,
    and `//` line comments immediately above a declaration for documentation.
    """
    blocks = re.findall(r'calc\s*"([^"]+)"\s*\{([^}]*)\}', text)
    if not blocks:
        raise ValueError('Input does not contain any calc "<path>" { ... } blocks')

    funcs = []
    for path, body in blocks:
        funcs.extend(_parse_block(path, body))

    parts: List[str] = ['(']

    # function typing rewrites
    for fn in funcs:
        name = fn['name']
        args = fn['args']
        ret = fn['ret']

        pat_elems = [f'({a} ${i})' for i, a in enumerate(args)]
        pat = f'({name}' + ((' ' + ' '.join(pat_elems)) if pat_elems else '') + ')'

        cons_items = [f'"{_escape(name)}"'] + [f'${i}' for i in range(len(args))]
        cons_chain = _cons_chain(cons_items)
        podman = f'(podman_bc_lp32_v0 (!load "file://{_escape(fn["path"])}") {cons_chain})'
        rhs = f'({ret} {podman})'

        parts.extend(['    (', f'        {pat}', f'        {rhs}', '    )'])

    # cast rewrites
    for fn in funcs:
        if fn['is_cast'] and len(fn['args']) >= 1:
            src = fn['args'][0]
            pat = f'({src} $0)'
            rhs = f'({fn["name"]} ({src} $0))'
            parts.extend(['    (', f'        {pat}', f'        {rhs}', '    )'])

    # docs
    for fn in funcs:
        if fn['doc']:
            name = fn['name']
            doc = fn['doc']
            parts.extend(['    (', f'        (Doc (Module "{_escape(name)}"))', f'        (Str "{_escape(doc)}")', '    )'])

    parts.append(')')
    return '\n'.join(parts)


if __name__ == '__main__':
    sample = r'''
calc "../calcutron/arithmetic.tar" {
    add : Int Int -> Int;

    // int2str translates a 32bit integer
    // into a string.
    int2str : Int -> Str;

    // str2int translates a string into a
    // 32bit integer.
    @cast
    str2int : Str -> Int;
}

calc "../calcutron/strings.tar" {
    concat : Str Str -> Str;
    length : Str -> Int;
}
'''
    print(parse(sample))
